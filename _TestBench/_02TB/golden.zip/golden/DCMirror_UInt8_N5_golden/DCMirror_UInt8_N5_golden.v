module DCMirror_UInt8_N5_golden(
  input        clock,
  input        reset,
  input  [4:0] io_dst,
  output       io_c_ready,
  input        io_c_valid,
  input  [7:0] io_c_bits,
  input        io_p_0_ready,
  output       io_p_0_valid,
  output [7:0] io_p_0_bits,
  input        io_p_1_ready,
  output       io_p_1_valid,
  output [7:0] io_p_1_bits,
  input        io_p_2_ready,
  output       io_p_2_valid,
  output [7:0] io_p_2_bits,
  input        io_p_3_ready,
  output       io_p_3_valid,
  output [7:0] io_p_3_bits,
  input        io_p_4_ready,
  output       io_p_4_valid,
  output [7:0] io_p_4_bits
);
`ifdef RANDOMIZE_REG_INIT
  reg [31:0] _RAND_0;
  reg [31:0] _RAND_1;
`endif // RANDOMIZE_REG_INIT
  reg [7:0] pData; // @[golden.scala 23:18]
  reg [4:0] pValid; // @[golden.scala 24:23]
  wire [4:0] pReady = {io_p_4_ready,io_p_3_ready,io_p_2_ready,io_p_1_ready,io_p_0_ready}; // @[Cat.scala 33:92]
  wire [4:0] _nxtAccept_T_2 = pValid & pReady; // @[golden.scala 26:69]
  wire  nxtAccept = pValid == 5'h0 | pValid != 5'h0 & _nxtAccept_T_2 == pValid; // @[golden.scala 26:36]
  wire [4:0] _pValid_T_1 = io_c_valid ? 5'h1f : 5'h0; // @[Bitwise.scala 77:12]
  wire [4:0] _pValid_T_2 = _pValid_T_1 & io_dst; // @[golden.scala 29:35]
  wire [4:0] _pValid_T_3 = ~pReady; // @[golden.scala 32:24]
  wire [4:0] _pValid_T_4 = pValid & _pValid_T_3; // @[golden.scala 32:22]
  assign io_c_ready = pValid == 5'h0 | pValid != 5'h0 & _nxtAccept_T_2 == pValid; // @[golden.scala 26:36]
  assign io_p_0_valid = pValid[0]; // @[golden.scala 38:28]
  assign io_p_0_bits = pData; // @[golden.scala 37:18]
  assign io_p_1_valid = pValid[1]; // @[golden.scala 38:28]
  assign io_p_1_bits = pData; // @[golden.scala 37:18]
  assign io_p_2_valid = pValid[2]; // @[golden.scala 38:28]
  assign io_p_2_bits = pData; // @[golden.scala 37:18]
  assign io_p_3_valid = pValid[3]; // @[golden.scala 38:28]
  assign io_p_3_bits = pData; // @[golden.scala 37:18]
  assign io_p_4_valid = pValid[4]; // @[golden.scala 38:28]
  assign io_p_4_bits = pData; // @[golden.scala 37:18]
  always @(posedge clock) begin
    if (nxtAccept) begin // @[golden.scala 28:19]
      pData <= io_c_bits; // @[golden.scala 30:11]
    end
    if (reset) begin // @[golden.scala 24:23]
      pValid <= 5'h0; // @[golden.scala 24:23]
    end else if (nxtAccept) begin // @[golden.scala 28:19]
      pValid <= _pValid_T_2; // @[golden.scala 29:12]
    end else begin
      pValid <= _pValid_T_4; // @[golden.scala 32:12]
    end
  end
// Register and memory initialization
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif
`ifndef RANDOM
`define RANDOM $random
`endif
`ifdef RANDOMIZE_MEM_INIT
  integer initvar;
`endif
`ifndef SYNTHESIS
`ifdef FIRRTL_BEFORE_INITIAL
`FIRRTL_BEFORE_INITIAL
`endif
initial begin
  `ifdef RANDOMIZE
    `ifdef INIT_RANDOM
      `INIT_RANDOM
    `endif
    `ifndef VERILATOR
      `ifdef RANDOMIZE_DELAY
        #`RANDOMIZE_DELAY begin end
      `else
        #0.002 begin end
      `endif
    `endif
`ifdef RANDOMIZE_REG_INIT
  _RAND_0 = {1{`RANDOM}};
  pData = _RAND_0[7:0];
  _RAND_1 = {1{`RANDOM}};
  pValid = _RAND_1[4:0];
`endif // RANDOMIZE_REG_INIT
  `endif // RANDOMIZE
end // initial
`ifdef FIRRTL_AFTER_INITIAL
`FIRRTL_AFTER_INITIAL
`endif
`endif // SYNTHESIS
endmodule
